import scrapy

class SongSpider(scrapy.Spider):
    name = "song"
    start_urls = [
        'https://www.npr.org/sections/allsongs/606254804/new-music-friday'
    ]

    def parse(self, response):
        for tag in response.css('FILL'):
            yield response.follow(tag, self.parse_article)

    def parse_article(self, response):
        artists = response.css('FILL').re('FILL')
        albums = response.css('FILL').getall()
        songs = response.css('FILL').re('FILL')
        yield {
            'artists': artists,
            'albums': albums,
            'songs': songs
        }
