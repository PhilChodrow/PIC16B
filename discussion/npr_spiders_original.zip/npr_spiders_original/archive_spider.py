# This worksheet was originally designed by [Erin George]
# (https://www.math.ucla.edu/~egeo/classes/spr21_pic16b-1/)
# (Department of Mathematics, UCLA), with subsequent
# revisions by John Zhang (Department of Mathematics, UCLA).

import scrapy

class ArchiveSpider(scrapy.Spider):
    name = "archive"
    start_urls = [
        'https://www.npr.org/sections/news/archive'
    ] # how do we get more?

    def parse(self, response):
        for article in response.css('article'):
            yield {
                'title': article.css('FILL').get(),
                'url': article.css('FILL').get(),
                'date': article.css('FILL').get(),
                'teaser': article.css('FILL').get()
            }